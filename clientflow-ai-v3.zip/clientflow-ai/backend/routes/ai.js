const express = require('express');
const router  = express.Router();
const auth    = require('../middleware/auth');
const db      = require('../db');

const { generateAIResponse, getProviderHealth, getActiveProvider } = require('../services/aiService');
const { generateMessage }  = require('../ai/features/messageGenerator');
const { generateAutoReply } = require('../ai/features/autoReply');
const { scoreLead }         = require('../ai/features/leadScorer');
const { summarizeChat }     = require('../ai/features/chatSummarizer');
const { detectLanguageAI }  = require('../ai/features/languageDetector');

router.use(auth);

// ─── Helper: fetch common business settings ───────────────────────────────────
async function getBizContext() {
  const rows  = (await db.query(`SELECT key, value FROM settings`)).rows;
  const find  = k => rows.find(s => s.key === k)?.value || '';
  return {
    bizName:    find('business_name') || 'our business',
    bizDesc:    find('business_description'),
    easypaisa:  find('easypaisa_number'),
    jazzcash:   find('jazzcash_number'),
  };
}

// ─── AI Broadcast Writer ──────────────────────────────────────────────────────
router.post('/write-broadcast', async (req, res) => {
  try {
    const { topic, tone, audience } = req.body;
    const { bizName, bizDesc } = await getBizContext();

    const result = await generateMessage({ topic, tone, audience, bizName, bizDescription: bizDesc });
    res.json({ message: result.message, provider: result.providerUsed });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// ─── AI Quick Reply Suggestion ────────────────────────────────────────────────
router.post('/suggest-reply', async (req, res) => {
  try {
    const { clientId, lastMessage } = req.body;
    const { bizName, easypaisa, jazzcash } = await getBizContext();

    const svcs = (await db.query(`SELECT name, price_pkr FROM services WHERE is_active=true`)).rows;
    const catalog = svcs.map(s => `${s.name}: PKR ${s.price_pkr}`).join(', ');

    const history = [];
    if (clientId) {
      const msgs = (await db.query(
        `SELECT direction, content FROM messages WHERE client_id=$1 ORDER BY created_at DESC LIMIT 10`,
        [clientId]
      )).rows.reverse();
      msgs.forEach(m => history.push({ role: m.direction === 'inbound' ? 'user' : 'assistant', content: m.content }));
    }

    const client = clientId
      ? (await db.query(`SELECT name FROM clients WHERE id=$1`, [clientId])).rows[0]
      : null;

    const result = await generateAutoReply({
      userMessage: lastMessage,
      history,
      bizName,
      catalog,
      clientName: client?.name,
      easypaisa,
      jazzcash,
      clientId,
    });

    res.json({ reply: result.reply, provider: result.providerUsed });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// ─── Lead Scoring ─────────────────────────────────────────────────────────────
router.post('/score-lead', async (req, res) => {
  try {
    const { clientId } = req.body;
    if (!clientId) return res.status(400).json({ error: 'clientId is required' });

    const msgs = (await db.query(
      `SELECT direction, content FROM messages WHERE client_id=$1 ORDER BY created_at ASC LIMIT 30`,
      [clientId]
    )).rows;

    const history = msgs.map(m => ({
      role:    m.direction === 'inbound' ? 'user' : 'assistant',
      content: m.content,
    }));

    const result = await scoreLead({ history, clientId });
    res.json(result);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// ─── Chat Summarization ───────────────────────────────────────────────────────
router.post('/summarize', async (req, res) => {
  try {
    const { clientId } = req.body;
    if (!clientId) return res.status(400).json({ error: 'clientId is required' });

    const msgs = (await db.query(
      `SELECT direction, content FROM messages WHERE client_id=$1 ORDER BY created_at ASC LIMIT 50`,
      [clientId]
    )).rows;

    const history = msgs.map(m => ({
      role:    m.direction === 'inbound' ? 'user' : 'assistant',
      content: m.content,
    }));

    const result = await summarizeChat({ history, clientId });
    res.json(result);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// ─── Language Detection ───────────────────────────────────────────────────────
router.post('/detect-language', async (req, res) => {
  try {
    const { text } = req.body;
    if (!text) return res.status(400).json({ error: 'text is required' });

    const result = await detectLanguageAI(text);
    res.json(result);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// ─── Upsell Message Generator ─────────────────────────────────────────────────
router.post('/upsell', async (req, res) => {
  try {
    const { clientId, serviceId } = req.body;
    const client  = (await db.query(`SELECT * FROM clients WHERE id=$1`, [clientId])).rows[0];
    const service = (await db.query(`SELECT * FROM services WHERE id=$1`, [serviceId])).rows[0];
    const others  = (await db.query(`SELECT * FROM services WHERE is_active=true AND id!=$1 LIMIT 5`, [serviceId])).rows;

    const { bizName } = await getBizContext();

    const result = await generateAIResponse({
      systemPrompt: `You are a sales assistant for ${bizName}. Write a short, friendly WhatsApp upsell message (max 2 sentences + CTA). No markdown, no asterisks.`,
      conversationHistory: [],
      userMessage: `Client just received: "${service?.name}". Suggest one of: ${others.map(s => `${s.name} (PKR ${s.price_pkr})`).join(', ')}. Client: ${client?.name || 'valued client'}.`,
    });

    res.json({ message: result.response });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// ─── Provider Health & Active Provider ────────────────────────────────────────
router.get('/health', (req, res) => {
  try {
    res.json({
      activeProvider: getActiveProvider(),
      providers:      getProviderHealth(),
    });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

module.exports = router;
