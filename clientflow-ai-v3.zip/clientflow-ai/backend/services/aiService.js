/**
 * aiService.js — Backward-compatible shim
 *
 * All existing callers (webhook.js, routes/ai.js, cronService.js, etc.)
 * continue to work unchanged.  The real logic now lives in ai/manager.js.
 *
 * Do NOT add new logic here — add it in the relevant ai/features/* file.
 */
const { generateAIResponse, getProviderHealth, getActiveProvider } = require('../ai/manager');

module.exports = { generateAIResponse, getProviderHealth, getActiveProvider };
