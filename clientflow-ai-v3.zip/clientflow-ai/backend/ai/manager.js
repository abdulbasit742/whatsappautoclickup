/**
 * Central AI Manager
 *
 * Responsibilities:
 *  - Instantiate all providers from config
 *  - Route every request through the active provider first
 *  - Automatic fallback to other configured providers when one fails
 *  - Per-provider health tracking with timed cooldown
 *  - DB logging of every AI call (provider, latency, success/failure)
 *
 * ─── How to add a new provider ───────────────────────────────────────────────
 *  1. Create backend/ai/providers/myprovider.js extending BaseProvider
 *  2. Add its key to PROVIDER_KEYS in ai/config.js
 *  3. Import and add to providerMap below
 *  4. Add 'myprovider' to FALLBACK_ORDER in ai/config.js
 *  5. Add MYPROVIDER_API_KEY to .env.example
 */

const { ACTIVE_PROVIDER, PROVIDER_KEYS, FALLBACK_ORDER, COOLDOWN_MS } = require('./config');

const GroqProvider   = require('./providers/groq');
const OpenAIProvider = require('./providers/openai');
const ClaudeProvider = require('./providers/claude');
const GeminiProvider = require('./providers/gemini');

// ─── Provider registry ────────────────────────────────────────────────────────
const providerMap = {
  groq:   new GroqProvider(PROVIDER_KEYS.groq),
  openai: new OpenAIProvider(PROVIDER_KEYS.openai),
  claude: new ClaudeProvider(PROVIDER_KEYS.claude),
  gemini: new GeminiProvider(PROVIDER_KEYS.gemini),
};

// ─── Health state ─────────────────────────────────────────────────────────────
const health = {};
for (const name of Object.keys(providerMap)) {
  health[name] = { available: true, lastError: null, lastUsed: null };
}

// ─── Ordered list: active provider first, then fallbacks ─────────────────────
function buildProviderChain() {
  const chain = [ACTIVE_PROVIDER];
  for (const p of FALLBACK_ORDER) {
    if (p !== ACTIVE_PROVIDER) chain.push(p);
  }
  return chain.filter(name => providerMap[name]?.isConfigured());
}

// ─── DB helper (optional — soft-fails if db is unavailable) ──────────────────
let db;
try { db = require('../db'); } catch (_) {}

async function logCall({ clientId, provider, latencyMs, success, errorMessage }) {
  if (!db) return;
  try {
    if (success) {
      await db.query(
        `INSERT INTO ai_logs (client_id, provider, latency_ms, success) VALUES ($1,$2,$3,true)`,
        [clientId, provider, latencyMs]
      );
    } else {
      await db.query(
        `INSERT INTO ai_logs (client_id, provider, latency_ms, success, error_message) VALUES ($1,$2,$3,false,$4)`,
        [clientId, provider, latencyMs, errorMessage]
      );
    }
  } catch (_) {}
}

// ─── Core dispatch ────────────────────────────────────────────────────────────
/**
 * @param {object} opts
 * @param {string}  opts.systemPrompt
 * @param {Array}   opts.history        - [{role, content}]
 * @param {string}  opts.userMessage
 * @param {string}  [opts.clientId]
 * @returns {Promise<{response:string|null, providerUsed:string|null, success:boolean}>}
 */
async function dispatch({ systemPrompt, history = [], userMessage, clientId = null }) {
  const chain = buildProviderChain();
  const start = Date.now();

  for (const name of chain) {
    if (!health[name].available) continue;
    const provider = providerMap[name];

    try {
      const response = await provider.call(systemPrompt, history, userMessage);
      const latencyMs = Date.now() - start;

      health[name].available = true;
      health[name].lastUsed  = new Date().toISOString();

      await logCall({ clientId, provider: name, latencyMs, success: true });

      return { response, providerUsed: name, success: true };
    } catch (err) {
      const latencyMs = Date.now() - start;
      const isRateLimit = err?.response?.status === 429 || err?.response?.status === 503;

      health[name].lastError = err.message;
      if (isRateLimit) {
        health[name].available = false;
        setTimeout(() => { health[name].available = true; }, COOLDOWN_MS);
      }

      await logCall({ clientId, provider: name, latencyMs, success: false, errorMessage: err.message });

      console.warn(`[AI Manager] ${name} failed (${err?.response?.status || err.code || 'error'}), trying next…`);
    }
  }

  console.error('[AI Manager] All providers exhausted — no response available.');
  return { response: null, providerUsed: null, success: false };
}

// ─── Public API ───────────────────────────────────────────────────────────────

/** Backwards-compatible alias used by the rest of the app. */
async function generateAIResponse({ systemPrompt, history, conversationHistory, userMessage, clientId }) {
  const h = history || conversationHistory || [];
  return dispatch({ systemPrompt, history: h, userMessage, clientId });
}

function getProviderHealth() {
  const result = {};
  for (const [name, state] of Object.entries(health)) {
    result[name] = {
      ...state,
      isActive:     name === ACTIVE_PROVIDER,
      isConfigured: providerMap[name].isConfigured(),
    };
  }
  return result;
}

function getActiveProvider() {
  return ACTIVE_PROVIDER;
}

module.exports = { dispatch, generateAIResponse, getProviderHealth, getActiveProvider };
