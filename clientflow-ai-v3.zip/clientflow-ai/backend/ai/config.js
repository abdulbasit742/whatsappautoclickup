/**
 * AI Engine Configuration
 *
 * Controls which provider is active, API keys, and fallback order.
 * To switch providers: set ACTIVE_AI_PROVIDER in .env
 *   e.g. ACTIVE_AI_PROVIDER=groq   (default)
 *        ACTIVE_AI_PROVIDER=openai
 *        ACTIVE_AI_PROVIDER=claude
 *        ACTIVE_AI_PROVIDER=gemini
 *
 * Fallback order: the manager tries ACTIVE_AI_PROVIDER first, then
 * cycles through FALLBACK_ORDER skipping providers with no API key.
 */

const ACTIVE_PROVIDER = (process.env.ACTIVE_AI_PROVIDER || 'groq').toLowerCase();

const PROVIDER_KEYS = {
  groq:   process.env.GROQ_API_KEY,
  openai: process.env.OPENAI_API_KEY,
  claude: process.env.ANTHROPIC_API_KEY,
  gemini: process.env.GEMINI_API_KEY,
};

// Providers attempted in order after the active one fails
const FALLBACK_ORDER = ['groq', 'openai', 'claude', 'gemini'];

// How long (ms) a rate-limited provider stays marked unavailable
const COOLDOWN_MS = 10 * 60 * 1000;

module.exports = { ACTIVE_PROVIDER, PROVIDER_KEYS, FALLBACK_ORDER, COOLDOWN_MS };
