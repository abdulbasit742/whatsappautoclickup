/**
 * Auto Reply
 *
 * Generates a context-aware customer-service reply
 * using the client's recent conversation history.
 */
const { dispatch }               = require('../manager');
const templates                  = require('../templates');
const { getLanguageInstruction } = require('./languageDetector');

/**
 * @param {object} opts
 * @param {string}  opts.userMessage
 * @param {Array}   opts.history        - [{role, content}]
 * @param {string}  opts.bizName
 * @param {string}  [opts.catalog]      - "Service A: PKR X, Service B: PKR Y"
 * @param {string}  [opts.clientName]
 * @param {string}  [opts.easypaisa]
 * @param {string}  [opts.jazzcash]
 * @param {string}  [opts.clientId]
 * @returns {Promise<{reply:string|null, providerUsed:string|null, success:boolean}>}
 */
async function generateAutoReply({
  userMessage,
  history = [],
  bizName,
  catalog = '',
  clientName,
  easypaisa,
  jazzcash,
  clientId,
}) {
  const systemPrompt =
    templates.autoReply({ bizName, catalog, clientName, easypaisa, jazzcash }) +
    getLanguageInstruction(userMessage);

  const { response, providerUsed, success } = await dispatch({
    systemPrompt,
    history,
    userMessage,
    clientId,
  });

  return { reply: response, providerUsed, success };
}

module.exports = { generateAutoReply };
