/**
 * Chat Summarizer
 *
 * Produces a structured JSON summary of a WhatsApp conversation:
 * summary text, key points, client sentiment, and unresolved issues.
 */
const { dispatch } = require('../manager');
const templates    = require('../templates');

/**
 * @param {object} opts
 * @param {Array}   opts.history   - [{role, content}]
 * @param {string}  [opts.clientId]
 * @returns {Promise<{summary, key_points, client_sentiment, unresolved_issues, providerUsed, success}>}
 */
async function summarizeChat({ history = [], clientId = null }) {
  const conversation = history
    .map(m => `${m.role === 'user' ? 'Client' : 'Agent'}: ${m.content}`)
    .join('\n');

  const systemPrompt = templates.chatSummary();

  const { response, providerUsed, success } = await dispatch({
    systemPrompt,
    history: [],
    userMessage: `Summarise this conversation:\n\n${conversation}`,
    clientId,
  });

  if (!success || !response) {
    return {
      summary: 'Unable to generate summary.',
      key_points: [],
      client_sentiment: 'neutral',
      unresolved_issues: [],
      providerUsed,
      success: false,
    };
  }

  try {
    const parsed = JSON.parse(response);
    return { ...parsed, providerUsed, success: true };
  } catch (_) {
    return {
      summary: response,
      key_points: [],
      client_sentiment: 'neutral',
      unresolved_issues: [],
      providerUsed,
      success: false,
    };
  }
}

module.exports = { summarizeChat };
