/**
 * Language Detector
 *
 * Fast heuristic detection (no AI call needed for the common case).
 * Falls back to AI-based detection when the pattern is ambiguous.
 */
const { dispatch } = require('../manager');
const templates    = require('../templates');

const URDU_RANGE   = /[\u0600-\u06FF]/;
const ARABIC_RANGE = /[\u0600-\u06FF\u0750-\u077F]/;
const CHINESE_RANGE = /[\u4E00-\u9FFF]/;
const HINDI_RANGE  = /[\u0900-\u097F]/;

/**
 * Lightweight heuristic detection (synchronous, no API call).
 * Returns ISO 639-1 code or 'en' as default.
 */
function detectLanguageSync(text) {
  if (URDU_RANGE.test(text))    return 'ur';
  if (ARABIC_RANGE.test(text))  return 'ar';
  if (HINDI_RANGE.test(text))   return 'hi';
  if (CHINESE_RANGE.test(text)) return 'zh';
  return 'en';
}

/**
 * AI-powered language detection with confidence and reply instruction.
 * @param {string} text
 * @returns {Promise<{language, confidence, script, reply_instruction}>}
 */
async function detectLanguageAI(text) {
  const systemPrompt = templates.languageDetection();
  const { response, success } = await dispatch({ systemPrompt, history: [], userMessage: text });

  if (!success || !response) {
    const lang = detectLanguageSync(text);
    return {
      language: lang,
      confidence: 'low',
      script: lang === 'en' ? 'latin' : 'arabic',
      reply_instruction: `Reply in ${lang === 'ur' ? 'Urdu' : 'English'}.`,
    };
  }

  try {
    return JSON.parse(response);
  } catch (_) {
    return { language: 'en', confidence: 'low', script: 'latin', reply_instruction: 'Reply in English.' };
  }
}

/**
 * Build language instruction string to append to any system prompt.
 */
function getLanguageInstruction(text) {
  const lang = detectLanguageSync(text);
  if (lang === 'ur') return '\n\nIMPORTANT: The user is writing in Urdu. Reply in Urdu (Roman or Arabic script — match their style).';
  if (lang === 'ar') return '\n\nIMPORTANT: The user is writing in Arabic. Reply in Arabic.';
  if (lang === 'hi') return '\n\nIMPORTANT: The user is writing in Hindi. Reply in Hindi.';
  return '\n\nIMPORTANT: Reply in English.';
}

module.exports = { detectLanguageSync, detectLanguageAI, getLanguageInstruction };
