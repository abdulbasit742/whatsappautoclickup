/**
 * Lead Scorer
 *
 * Analyses a conversation and returns a 0-100 lead score,
 * tier classification (cold / warm / hot), intent summary,
 * and recommended next action.
 */
const { dispatch } = require('../manager');
const templates    = require('../templates');

/**
 * @param {object} opts
 * @param {Array}   opts.history   - [{role, content}] full conversation
 * @param {string}  [opts.clientId]
 * @returns {Promise<{score, tier, intent, recommended_action, providerUsed, success}>}
 */
async function scoreLead({ history = [], clientId = null }) {
  const conversation = history
    .map(m => `${m.role === 'user' ? 'Client' : 'Agent'}: ${m.content}`)
    .join('\n');

  const systemPrompt = templates.leadScoring();

  const { response, providerUsed, success } = await dispatch({
    systemPrompt,
    history: [],
    userMessage: `Analyse this conversation and return the JSON:\n\n${conversation}`,
    clientId,
  });

  if (!success || !response) {
    return { score: 0, tier: 'cold', intent: 'unknown', recommended_action: 'Manual review required', providerUsed, success: false };
  }

  try {
    const parsed = JSON.parse(response);
    return { ...parsed, providerUsed, success: true };
  } catch (_) {
    return { score: 0, tier: 'cold', intent: 'parse error', recommended_action: 'Manual review required', providerUsed, success: false };
  }
}

module.exports = { scoreLead };
