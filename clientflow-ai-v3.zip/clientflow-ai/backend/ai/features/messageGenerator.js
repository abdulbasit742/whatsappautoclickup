/**
 * Message Generator
 *
 * Generates WhatsApp broadcast / marketing messages from a topic.
 */
const { dispatch }                  = require('../manager');
const templates                     = require('../templates');
const { getLanguageInstruction }    = require('./languageDetector');

/**
 * @param {object} opts
 * @param {string}  opts.topic
 * @param {string}  [opts.tone]
 * @param {string}  [opts.audience]
 * @param {string}  opts.bizName
 * @param {string}  [opts.bizDescription]
 * @returns {Promise<{message:string|null, providerUsed:string|null, success:boolean}>}
 */
async function generateMessage({ topic, tone, audience, bizName, bizDescription = '' }) {
  const systemPrompt =
    templates.messageGeneration({ bizName, bizDescription, tone, audience }) +
    getLanguageInstruction(topic);

  const { response, providerUsed, success } = await dispatch({
    systemPrompt,
    history: [],
    userMessage: `Write a WhatsApp broadcast message about: ${topic}`,
  });

  return { message: response, providerUsed, success };
}

module.exports = { generateMessage };
