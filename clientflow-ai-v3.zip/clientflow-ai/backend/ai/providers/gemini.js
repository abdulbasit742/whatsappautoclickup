const axios = require('axios');
const BaseProvider = require('./base');

/**
 * Gemini (Google) Provider — PLACEHOLDER
 * Activate by setting ACTIVE_AI_PROVIDER=gemini in .env
 * Requires: GEMINI_API_KEY
 */
class GeminiProvider extends BaseProvider {
  constructor(apiKey) {
    super('gemini', apiKey);
    this.model = process.env.GEMINI_MODEL || 'gemini-1.5-flash';
    this.apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/${this.model}:generateContent`;
  }

  async call(systemPrompt, history, userMessage) {
    const contents = [
      ...history.map(m => ({
        role: m.role === 'assistant' ? 'model' : 'user',
        parts: [{ text: m.content }],
      })),
      { role: 'user', parts: [{ text: userMessage }] },
    ];

    const res = await axios.post(
      `${this.apiUrl}?key=${this.apiKey}`,
      { system_instruction: { parts: [{ text: systemPrompt }] }, contents }
    );

    return res.data.candidates[0].content.parts[0].text;
  }
}

module.exports = GeminiProvider;
