/**
 * Base AI Provider
 *
 * All concrete providers extend this class and implement `call()`.
 * To add a new provider:
 *   1. Create backend/ai/providers/myprovider.js extending BaseProvider
 *   2. Implement async call(systemPrompt, history, userMessage) → string
 *   3. Register it in backend/ai/manager.js providerMap
 *   4. Add its API key to config.js PROVIDER_KEYS and .env.example
 */
class BaseProvider {
  /**
   * @param {string} name  - Unique provider identifier (e.g. 'groq')
   * @param {string} [apiKey] - API key for this provider
   */
  constructor(name, apiKey) {
    this.name = name;
    this.apiKey = apiKey;
  }

  /** Returns true if the provider has an API key configured. */
  isConfigured() {
    return Boolean(this.apiKey);
  }

  /**
   * Send a chat completion request.
   * @param {string}   systemPrompt
   * @param {Array<{role:string, content:string}>} history
   * @param {string}   userMessage
   * @returns {Promise<string>} The AI response text
   */
  async call(systemPrompt, history, userMessage) { // eslint-disable-line no-unused-vars
    throw new Error(`Provider "${this.name}" has not implemented call()`);
  }
}

module.exports = BaseProvider;
