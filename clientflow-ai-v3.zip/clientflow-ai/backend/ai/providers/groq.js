const axios = require('axios');
const BaseProvider = require('./base');

/**
 * Groq Provider — ACTIVE
 * Model: llama-3.3-70b-versatile (fast, free-tier available)
 * Docs: https://console.groq.com/docs/openai
 */
class GroqProvider extends BaseProvider {
  constructor(apiKey) {
    super('groq', apiKey);
    this.model = process.env.GROQ_MODEL || 'llama-3.3-70b-versatile';
    this.apiUrl = 'https://api.groq.com/openai/v1/chat/completions';
  }

  async call(systemPrompt, history, userMessage) {
    const messages = [
      { role: 'system', content: systemPrompt },
      ...history.map(m => ({ role: m.role, content: m.content })),
      { role: 'user', content: userMessage },
    ];

    const res = await axios.post(
      this.apiUrl,
      { model: this.model, messages, max_tokens: 1024 },
      { headers: { Authorization: `Bearer ${this.apiKey}`, 'Content-Type': 'application/json' } }
    );

    return res.data.choices[0].message.content;
  }
}

module.exports = GroqProvider;
