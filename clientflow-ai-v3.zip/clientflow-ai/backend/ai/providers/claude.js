const axios = require('axios');
const BaseProvider = require('./base');

/**
 * Claude (Anthropic) Provider — PLACEHOLDER
 * Activate by setting ACTIVE_AI_PROVIDER=claude in .env
 * Requires: ANTHROPIC_API_KEY
 */
class ClaudeProvider extends BaseProvider {
  constructor(apiKey) {
    super('claude', apiKey);
    this.model = process.env.CLAUDE_MODEL || 'claude-3-5-sonnet-20241022';
    this.apiUrl = 'https://api.anthropic.com/v1/messages';
  }

  async call(systemPrompt, history, userMessage) {
    const res = await axios.post(
      this.apiUrl,
      {
        model: this.model,
        max_tokens: 1024,
        system: systemPrompt,
        messages: [
          ...history.map(m => ({ role: m.role, content: m.content })),
          { role: 'user', content: userMessage },
        ],
      },
      {
        headers: {
          'x-api-key': this.apiKey,
          'anthropic-version': '2023-06-01',
          'Content-Type': 'application/json',
        },
      }
    );

    return res.data.content[0].text;
  }
}

module.exports = ClaudeProvider;
