const axios = require('axios');
const BaseProvider = require('./base');

/**
 * OpenAI Provider — PLACEHOLDER
 * Activate by setting ACTIVE_AI_PROVIDER=openai in .env
 * Requires: OPENAI_API_KEY
 */
class OpenAIProvider extends BaseProvider {
  constructor(apiKey) {
    super('openai', apiKey);
    this.model = process.env.OPENAI_MODEL || 'gpt-4o';
    this.apiUrl = 'https://api.openai.com/v1/chat/completions';
  }

  async call(systemPrompt, history, userMessage) {
    const messages = [
      { role: 'system', content: systemPrompt },
      ...history.map(m => ({ role: m.role, content: m.content })),
      { role: 'user', content: userMessage },
    ];

    const res = await axios.post(
      this.apiUrl,
      { model: this.model, messages, max_tokens: 1024 },
      { headers: { Authorization: `Bearer ${this.apiKey}`, 'Content-Type': 'application/json' } }
    );

    return res.data.choices[0].message.content;
  }
}

module.exports = OpenAIProvider;
